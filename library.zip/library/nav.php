<ul class="navbar-nav ml-auto">
  <li class="nav-item">
    <a class="nav-link" href="search_book.php">Seach</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="insertbook.php">Insert</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="insertbook.php">Listbook</a>
  </li>
</ul>
